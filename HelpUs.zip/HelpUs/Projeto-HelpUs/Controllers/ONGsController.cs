﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Projeto_HelpUs.Models;

namespace Projeto_HelpUs.Controllers
{
    public class ONGsController : Controller
    {
        private readonly Projeto_HelpUsContext _context;

        public ONGsController(Projeto_HelpUsContext context)
        {
            _context = context;
        }

        // GET: ONGs
        public async Task<IActionResult> Index()
        {
            return View(await _context.ONG.ToListAsync());
        }

        // GET: ONGs/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oNG = await _context.ONG
                .FirstOrDefaultAsync(m => m.OngID == id);
            if (oNG == null)
            {
                return NotFound();
            }

            return View(oNG);
        }

        // GET: ONGs/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: ONGs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("OngID,NomeFantasia,RazaoSocial,Proprietario,CNPJ,CEP,Endereco,Bairro,Cidade,Estado,Telefone,Email,Senha,ConfirmarSenha,TermosOng")] ONG oNG)
        {
            if (ModelState.IsValid)
            {
                _context.Add(oNG);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(oNG);
        }

        // GET: ONGs/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oNG = await _context.ONG.FindAsync(id);
            if (oNG == null)
            {
                return NotFound();
            }
            return View(oNG);
        }

        // POST: ONGs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("OngID,NomeFantasia,RazaoSocial,Proprietario,CNPJ,CEP,Endereco,Bairro,Cidade,Estado,Telefone,Email,Senha,ConfirmarSenha,TermosOng")] ONG oNG)
        {
            if (id != oNG.OngID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(oNG);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ONGExists(oNG.OngID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(oNG);
        }

        // GET: ONGs/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oNG = await _context.ONG
                .FirstOrDefaultAsync(m => m.OngID == id);
            if (oNG == null)
            {
                return NotFound();
            }

            return View(oNG);
        }

        // POST: ONGs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var oNG = await _context.ONG.FindAsync(id);
            _context.ONG.Remove(oNG);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ONGExists(int id)
        {
            return _context.ONG.Any(e => e.OngID == id);
        }
    }
}
