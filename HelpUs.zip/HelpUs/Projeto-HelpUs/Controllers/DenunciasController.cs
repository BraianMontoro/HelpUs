﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Projeto_HelpUs.Models;

namespace Projeto_HelpUs.Controllers
{
    public class DenunciasController : Controller
    {
        private readonly Projeto_HelpUsContext _context;

        public DenunciasController(Projeto_HelpUsContext context)
        {
            _context = context;
        }

        // GET: Denuncias
        public async Task<IActionResult> Index()
        {
            return View(await _context.Denuncias.ToListAsync());
        }

        // GET: Denuncias/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var denuncias = await _context.Denuncias
                .FirstOrDefaultAsync(m => m.DenunciasID == id);
            if (denuncias == null)
            {
                return NotFound();
            }

            return View(denuncias);
        }

        // GET: Denuncias/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Denuncias/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("DenunciasID,Titulo,Descricao,Data")] Denuncias denuncias)
        {
            if (ModelState.IsValid)
            {
                _context.Add(denuncias);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(denuncias);
        }

        // GET: Denuncias/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var denuncias = await _context.Denuncias.FindAsync(id);
            if (denuncias == null)
            {
                return NotFound();
            }
            return View(denuncias);
        }

        // POST: Denuncias/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("DenunciasID,Titulo,Descricao,Data")] Denuncias denuncias)
        {
            if (id != denuncias.DenunciasID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(denuncias);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DenunciasExists(denuncias.DenunciasID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(denuncias);
        }

        // GET: Denuncias/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var denuncias = await _context.Denuncias
                .FirstOrDefaultAsync(m => m.DenunciasID == id);
            if (denuncias == null)
            {
                return NotFound();
            }

            return View(denuncias);
        }

        // POST: Denuncias/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var denuncias = await _context.Denuncias.FindAsync(id);
            _context.Denuncias.Remove(denuncias);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DenunciasExists(int id)
        {
            return _context.Denuncias.Any(e => e.DenunciasID == id);
        }
    }
}
