﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Projeto_HelpUs.Models
{
    public class ONG
    {
        public int OngID { get; set; }

        [Required(ErrorMessage = "Por favor preencha o campo Nome Fantasia.")]
        [StringLength(255, MinimumLength = 1)]
        public string NomeFantasia { get; set; }

        [Required(ErrorMessage = "Por favor preencha o campo Razão Social.")]
        [StringLength(255, MinimumLength = 1)]
        public string RazaoSocial { get; set; }

        [Required(ErrorMessage = "Por favor preencha o campo Proprietário.")]
        [StringLength(255, MinimumLength = 1)]
        public string Proprietario { get; set; }

        [Required(ErrorMessage = "Por favor escolha uma Causa.")]
        public Causas Causa { get; set; }

        [Required(ErrorMessage = "Por favor preencha o campo CNPJ.")]
        //[RegularExpression("[0-9]{2}/.?[0 - 9]{3}/.?[0 - 9]{3}/-?[0 - 9]{4}//?[0 - 9]{2}")]
        public string CNPJ { get; set; }

        [Required(ErrorMessage = "Por favor preencha o campo CEP.")]
        //[RegularExpression("[0-9]{5}/-?[0 - 9]{3}")]
        public string CEP { get; set; }

        public string Endereco { get; set; }
        public string Bairro { get; set; }
        public string Cidade { get; set; }
        public string Estado { get; set; }

        [Required(ErrorMessage = "Por favor preencha o campo Telefone.")]
        public string Telefone { get; set; }

        [Required(ErrorMessage = "Por favor preencha o campo E-mail.")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Por favor digite a Senha")]
        [DataType(DataType.Password)]
        public string Senha { get; set; }

        [Required(ErrorMessage = "Por favor digite a Confirmação de senha")]
        [DataType(DataType.Password)]
        [Compare("Senha", ErrorMessage = "Confirmação de senha não corresponde.")]
        public string ConfirmarSenha { get; set; }

        [RegularExpression("Por favor Aceite os termos de uso")]
        public Boolean TermosOng { get; set; }

    }
}
