﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Projeto_HelpUs.Models
{
    public class Notificacoes
    {
        public int NotificacoesID { get; set; }

        [Required(ErrorMessage = "Por favor preencha o título.")]
        [StringLength(255, MinimumLength = 10)]
        public string Titulo { get; set; }

        [Required(ErrorMessage = "Por favor preencha a descrição.")]
        [StringLength(255, MinimumLength = 20)]
        public string Descricao { get; set; }

        public Boolean Ativo { get; set; }

    }
}
