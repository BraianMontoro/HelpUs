﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Projeto_HelpUs.Models
{
    public class Administrador
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "Por favor informe seu Nome.")]
        [StringLength(255, MinimumLength = 2)]
        public string Nome { get; set; }

        [Required(ErrorMessage = "Por favor informe seu E-mail.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Por favor informe sua Senha.")]
        [DataType(DataType.Password)]
        public string Senha { get; set; }

        [Required(ErrorMessage = "Por favor confirme sua Senha.")]
        [DataType(DataType.Password)]
        public string ConfirmarSenha { get; set; }

    }
}
