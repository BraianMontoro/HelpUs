﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Projeto_HelpUs.Models
{
    public class Voluntario
    {
        public int VoluntarioID { get; set; }

        [Required(ErrorMessage = "Por favor preencha o campo Nome.")]
        [StringLength(255, MinimumLength = 1)]
        public string Nome { get; set; }

        [Required(ErrorMessage = "Por favor preencha o campo CPF.")]
        [RegularExpression("[0-9]{3}?[0-9]{3}?[0-9]{3}?[0-9]{2}")]
        public string CPF { get; set; }

        [Required(ErrorMessage = "Por favor preencha o campo Data.")]
        [DataType(DataType.Date)]
        public DateTime Data { get; set; }

        [Required(ErrorMessage = "Por favor selecione uma Habilidade")]
        public Habilidades habilidades { get; set; }

        [Required(ErrorMessage = "Por favor preencha o campo CEP")]
        [RegularExpression("\\d{5}-\\d{3}")]
        public string CEP { get; set; }

        public string Endereco { get; set; }
        public string Bairro { get; set; }
        public string Cidade { get; set; }
        public string Estado { get; set; }

        [Required(ErrorMessage = "Por favor preencha o campo E-mail")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Por favor digite a Senha")]
        [DataType(DataType.Password)]
        public string Senha { get; set; }

        [Required(ErrorMessage = "Por favor digite a Confirmação de senha")]
        [DataType(DataType.Password)]
        public string ConfirmarSenha { get; set; }

        [Required(ErrorMessage = "Por favor Aceite os termos de uso do voluntário")]
        public Boolean TermosVoluntario { get; set; }

    }
}
