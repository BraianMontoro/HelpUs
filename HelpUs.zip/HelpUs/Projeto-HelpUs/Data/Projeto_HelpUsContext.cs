﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Projeto_HelpUs.Models;

namespace Projeto_HelpUs.Models
{
    public class Projeto_HelpUsContext : DbContext
    {
        public Projeto_HelpUsContext (DbContextOptions<Projeto_HelpUsContext> options)
            : base(options)
        {
        }

        public DbSet<Projeto_HelpUs.Models.Administrador> Administrador { get; set; }

        public DbSet<Projeto_HelpUs.Models.Causas> Causas { get; set; }

        public DbSet<Projeto_HelpUs.Models.Denuncias> Denuncias { get; set; }

        public DbSet<Projeto_HelpUs.Models.Habilidades> Habilidades { get; set; }

        public DbSet<Projeto_HelpUs.Models.Notificacoes> Notificacoes { get; set; }

        public DbSet<Projeto_HelpUs.Models.ONG> ONG { get; set; }

        public DbSet<Projeto_HelpUs.Models.Voluntario> Voluntario { get; set; }

        public DbSet<Projeto_HelpUs.Models.Imagem> Imagem { get; set; }
    }
}
